import 'package:flutter/material.dart';
import 'package:english_words/english_words.dart'; // Add this line.
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'package:hello_me/auth_repository.dart';
import 'package:hello_me/FavoritesRepository.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(App());
}

class App extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
              body: Center(
                  child: Text(snapshot.error.toString(),
                      textDirection: TextDirection.ltr)));
        }
        if (snapshot.connectionState == ConnectionState.done) {
          return MyApp();
        }
        return Center(
          child: CircularProgressIndicator(),
        );
      },
    );
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthRepository.instance()),
        ChangeNotifierProxyProvider<AuthRepository, FavoritesRepository>(
            create: (_) => FavoritesRepository(),
            update: (_, auth, favorites) => favorites!..updateFavorites(auth))
      ],
      child: MaterialApp(
        title: 'Startup Name Generator',
        theme: ThemeData(
          // Add the 3 lines from here...
          primaryColor: Colors.red,
        ),
        home: RandomWords(),
      ),
    );
  }
}

class RandomWords extends StatefulWidget {
  @override
  _RandomWordsState createState() => _RandomWordsState();
}

class _RandomWordsState extends State<RandomWords> {
  final _suggestions = generateWordPairs().take(10).toList(); // NEW
  final _biggerFont = const TextStyle(fontSize: 18); // NEW

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthRepository>(
        builder: (context, auth, _) => Scaffold(
              // Add from here...
              appBar: AppBar(
                title: Text('Startup Name Generator'),
                actions: [
                  IconButton(
                      icon: Icon(Icons.exit_to_app),
                      onPressed: auth.status == Status.Authenticated
                          ? () {
                              auth.signOut();
                            }
                          : null),
                  IconButton(
                      icon: Icon(Icons.favorite),
                      onPressed: _pushSaved
                  ),
                  IconButton(
                      icon: Icon(Icons.login),
                      onPressed: auth.status != Status.Authenticated
                          ? _pushLogin
                          : null)
                ],
              ),
              body: _buildSuggestions(),
            ));
    //final wordPair = WordPair.random(); // NEW
    //return Text(wordPair.asPascalCase); // NEW

  }

  Widget _buildSuggestions() {
    return ListView.builder(
        padding: const EdgeInsets.all(16),
        // The itemBuilder callback is called once per suggested
        // word pairing, and places each suggestion into a ListTile
        // row. For even rows, the function adds a ListTile row for
        // the word pairing. For odd rows, the function adds a
        // Divider widget to visually separate the entries. Note that
        // the divider may be difficult to see on smaller devices.
        itemBuilder: (BuildContext _context, int i) {
          // Add a one-pixel-high divider widget before each row
          // in the ListView.
          if (i.isOdd) {
            return Divider();
          }

          // The syntax "i ~/ 2" divides i by 2 and returns an
          // integer result.
          // For example: 1, 2, 3, 4, 5 becomes 0, 1, 1, 2, 2.
          // This calculates the actual number of word pairings
          // in the ListView,minus the divider widgets.
          final int index = i ~/ 2;
          // If you've reached the end of the available word
          // pairings...

          if (index >= _suggestions.length) {
            // ...then generate 10 more and add them to the
            // suggestions list.
            _suggestions.addAll(generateWordPairs().take(10));
          }
          return _buildRow(_suggestions[index]);
        });
  }

  Widget _buildRow(WordPair pair) {
    return Consumer<FavoritesRepository>(
      builder: (context, fave, _) => ListTile(
        title: Text(
          pair.asPascalCase,
          style: _biggerFont,
        ),
        trailing: Icon(
          // NEW from here...
          fave.currentSet.contains(pair) ? Icons.favorite : Icons.favorite_border,
          color: fave.currentSet.contains(pair) ? Colors.red : null,
        ),
        onTap: () {
          // NEW lines from here...
            if (fave.currentSet.contains(pair)) {
              fave.deleteSingleFavorite(pair);
            } else {
              fave.addSingleFavorite(pair);
            }

        },
      ),
    );
  }

  void _pushLogin() {
    TextEditingController emailController = new TextEditingController();
    TextEditingController passwordController = new TextEditingController();

    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) {
          return Scaffold(
              appBar: AppBar(
                title: Text('Login'),
                centerTitle: true,
              ),
              body: Container(
                padding: EdgeInsets.fromLTRB(20, 30, 20, 20),
                child: Column(
                  children: [
                    Text(
                        'Welcome to Startup Names Generator, please log in below'),
                    Padding(padding: EdgeInsets.fromLTRB(20, 30, 20, 20)),
                    TextField(
                      decoration: InputDecoration(labelText: 'Email'),
                      controller: emailController,
                    ),
                    Padding(padding: EdgeInsets.fromLTRB(0, 20, 0, 0)),
                    TextField(
                      decoration: InputDecoration(labelText: 'Password'),
                      controller: passwordController,
                    ),
                    ConstrainedBox(
                      constraints: BoxConstraints.tightFor(width: 400),
                      child: Consumer<AuthRepository>(
                        builder: (context, auth, _) => ElevatedButton(
                            onPressed: auth.status == Status.Authenticating
                                ? null
                                : () {
                                    _pushLoginButton(auth, emailController.text,
                                        passwordController.text);
                                  },
                            child: Text('Log in'),
                            style: ElevatedButton.styleFrom(
                              primary: Colors.red,
                            )),
                      ),
                    )
                  ],
                ),
              ));
        },
      ),
    );
  }

  void _pushLoginButton(AuthRepository auth, String email, String password) {
    auth.signIn(email, password).then((value) {
      if (value) {
        /*FavoritesRepository fav = new FavoritesRepository();
        fav.updateFavorites(auth);*/
        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('There was an error logging into the app')));
      }
    });
  }

  void _deletePressed(WordPair pair, FavoritesRepository faves) {
    //TODO: activate delete from FavoritesRepository
    faves.deleteSingleFavorite(pair);
  }

  void _pushSaved() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        // NEW lines from here...
        //TODO: changed _saved to a consumed set


        builder: (BuildContext context) {
          final favorites = Provider.of<FavoritesRepository>(context).currentSet;
          if (favorites.isEmpty){
            return Scaffold(
              appBar: AppBar(
                title: Text('Saved Suggestions'),
              ),
            );
          }
          final tiles = favorites.map(
            (WordPair pair) {
              return ListTile(
                title: Text(
                  pair.asPascalCase,
                  style: _biggerFont,
                ),
                trailing: Consumer<FavoritesRepository>(builder:(context, fave, _) =>IconButton(
                  icon: Icon(

                    // NEW from here...
                      Icons.delete_outline,
                      color: Colors.red),
                  onPressed: (){_deletePressed(pair,fave);},
                ) ,
                ),
              );
            },
          );
          final divided = ListTile.divideTiles(
            context: context,
            tiles: tiles,
          ).toList();


          return Scaffold(
            appBar: AppBar(
              title: Text('Saved Suggestions'),
            ),
            body: ListView(children: divided),
          );
        }, // ...to here.
      ),
    );
  }
}
